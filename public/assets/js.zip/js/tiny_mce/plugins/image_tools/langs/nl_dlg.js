tinyMCE.addI18n('nl.alt_dlg',{
	title : 'Alternatieve tekst',
	tabone : 'Alternatieve tekst voor deze afbeelding.'
    
});

tinyMCE.addI18n('nl.image_tools',{

    alt : 'Alternatieve tekst',
    float_left : 'Links van de tekst uitlijnen',
    float_right : 'Rechts van de tekst uitlijnen',
    float_none : 'Niet uitlijnen',
    width_plus : 'Vergroten',
    width_original : 'Originele grootte',
    width_min : 'Verkleinen',
    remove : 'Verwijder deze afbeelding',
    edit : 'Wijzig afbeelding',
    alt_label : 'Alt tekst',
    
    float_left_label : 'Links',
    float_right_label : 'Rechts',
    float_none_label : 'Niet',
    width_plus_label : 'Vergroten',
    width_original_label : 'Originele grootte',
    width_min_label : 'Verkleinen',
    remove_label : 'Verwijder afbeelding',
    edit_label : 'Wijzig afbeelding'
    
    
});

tinyMCE.addI18n('en.alt_dlg',{
	title : 'Alternative text',
	tabone : 'Type the alternative text for this picture.'
    
});

tinyMCE.addI18n('en.image_tools',{

    alt : 'Edit / Insert alternative text',
    float_left : 'Align this image left to the content',
    float_right : 'Align this image right to the content',
    float_none : 'Don\'t wrap any text around this image',
    width_plus : 'Grow',
    width_original : 'Origanl size',
    width_min : 'Shrink',
    remove : 'Remove this image',
    edit : 'Edit this image',
    alt_label : 'Alt text',
    
    width_original_label : 'Original size', 
    float_left_label : 'Float left',
    float_right_label : 'Float right',
    float_none_label : 'Float none',
    width_orignal_label : 'Origanal size',  
    width_plus_label : 'Grow',
    width_min_label : 'Shrink',
    remove_label : 'Remove image',
    edit_label : 'Edit image'
    
    
});

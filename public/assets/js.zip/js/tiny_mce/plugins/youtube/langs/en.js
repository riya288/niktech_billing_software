// UK lang variables

tinyMCE.addToLang('youtube',{
title : 'Insert / edit YouTube Movie',
desc : 'Insert / edit YouTube Movie',
file : 'Movie ID',
size : 'Size',
list : 'You Tube movies',
props : 'YouTube properties',
general : 'General'
});

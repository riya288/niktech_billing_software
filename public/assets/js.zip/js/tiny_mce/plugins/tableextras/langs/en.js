tinyMCE.addI18n('en.tableextras',{
	convertcellsinrow: 'Convert cell type for current row',
	tabledraw : 'Create table',
	tabledrawclose : 'Close',
    label : 'Table'
});

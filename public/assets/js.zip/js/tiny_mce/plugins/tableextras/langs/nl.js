tinyMCE.addI18n('nl.tableextras',{
	convertcellsinrow: 'Celtype wijzigen in deze rij',
	tabledraw : 'Tabel invoegen',
	tabledrawclose : 'Sluiten',
    label : 'Tabel'  
});
        
        
            



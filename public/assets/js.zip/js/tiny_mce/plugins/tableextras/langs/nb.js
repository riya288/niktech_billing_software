tinyMCE.addI18n('nb.tableextras',{
	convertcellsinrow: 'Konverter celle type for gjeldende rad',
	tabledraw : 'Lag tabell',
	tabledrawclose : 'Lukk'
});

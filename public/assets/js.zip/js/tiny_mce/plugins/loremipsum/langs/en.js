tinyMCE.addI18n('en.loremipsum',{
    desc : 'Insert Lorem Ipsum dummy text',
    label : 'Dummy text'
});

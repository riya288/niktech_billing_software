tinyMCE.addI18n('nl.loremipsum',{
    desc : 'Dummy tekst toevoegen',
    label : 'Dummy tekst'
});

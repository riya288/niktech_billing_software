tinyMCE.addI18n('nl.bestandsbeheer',{
      file : 'Bestand',
      video : 'Video',
      mp3 : 'MP3'
});

tinyMCE.addI18n('en.bestandsbeheer',{
      file : 'File',
      video : 'Video',
      mp3 : 'MP3'
});

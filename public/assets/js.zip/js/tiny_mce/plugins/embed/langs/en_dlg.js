tinyMCE.addI18n('en.embed_dlg',{
	title : 'Insert Embed Code',
	tabone : 'Insert Embed Code',
    paste : 'Paste Embed code',
    error_empty : 'Please insert embed code.',
    error_valid : 'This embed code is not valid.' 
});

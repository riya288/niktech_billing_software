tinyMCE.addI18n('nl.embed_dlg',{
	title : 'Embedcode invoegen',
	tabone : 'Embedcode invoegen',
    paste : 'Plak hier de embed code'
});

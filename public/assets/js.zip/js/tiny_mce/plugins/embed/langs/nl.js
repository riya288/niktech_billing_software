tinyMCE.addI18n('nl.embed',{
	desc : 'Voeg Embed Code van YouTube, Vimeo, Flickr, Google Maps, etc. toe',
    label : 'Embed',
    edit : 'Wijzig embed code',
    shrink : 'Verkleinen',
    grow : 'Vergroten',
    remove : 'Verwijder embed code',
    left_desc : 'Links uitlijnen van de tekst',
    left : 'Links',
    right_desc : 'Rechts uitlijnen van de tekst',
    right : 'Rechts',
    none_desc : 'Niet uitlijnen',
    none : 'Niet' 
});
